package com.example.SpringSecurityEx.web;

import javax.annotation.security.RolesAllowed;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

@Service
public class UserService  {
	
	    @RolesAllowed({"ROLE_ADMIN"})
	public String secureMet() throws Exception{
		return "Serviceclass";
		
	}


}
