package com.example.SpringSecurityEx.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.security.PermitAll;
import javax.annotation.security.RolesAllowed;

@RestController
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService userService;

	@GetMapping("anon1")
	/* @PermitAll */
	@RolesAllowed({ "ROLE_ADMIN" })
	public String anonymously() {
		return "Hello World!!!";
	}

	@GetMapping("admin-role")
	@RolesAllowed({ "ROLE_ADMIN" })
	public String hasRole() {
		return "Hello World!!!";

	}

	@GetMapping("service-admin-role")
	public String fromServiceMethod() throws Exception {
		return userService.secureMet();

	}
}
