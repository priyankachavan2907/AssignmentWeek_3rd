function display(){
//alert("Helloooooooooooooooo");
//add values in text boxes and display alert
//console.log();
var v1 = document.getElementById("val1").value;
var v2 = document.getElementById("val2").value;
var result = parseInt(v1)+parseInt(v2);
alert("Sum is "+ result);
//create another input text in HTML and put above result in that
    //var text=document.createElement("input") ;
    document.getElementById("abc").innerHTML+= "<input type= 'text' value='"+result+"'/>";
}
