import { Options } from './options';

import {Component, NgModule} from '@angular/core'
;
import {BrowserModule} from '@angular/platform-browser';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})


export class AppComponent {
  
selectedOption:Options = new Options(2, 'T-Shirts');
  

options = [
     new Options(1, 'Jeans' ),
     new Options(2, 'T-Shirts' ),
     new Options(3, 'Shorts' ),
     new Options(4, 'Shirts')
,     new Options(5, 'Trousers'),
     new Options(6, 'Chinos'),
     new Options(7, 'Shoes')
  ];
  
  

getValue(optionid:number) 
{
      
this.selectedOption = this.options.filter((item)=> item.id == optionid)[0];
  
}


}